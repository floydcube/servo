import RPi.GPIO as GPIO


class Servo():
    def __init__ (self, pin=12, frep=50):
        self.pin=pin
        self.frep=frep
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.pin, self.frep)
        self.p=GPIO.PWM(self.pin, self.frep)
        self.p.start(3)

    def setDuty(self,dc=10):
        self.p.ChangeDutyCycle(dc)
    
    def stop(self):
        self.p.stop()
